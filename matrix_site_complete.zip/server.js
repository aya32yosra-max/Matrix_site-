const express = require("express");
const path = require("path");
const Database = require("better-sqlite3");

const app = express();
const PORT = process.env.PORT || 3000;

const db = new Database("matrix.db");
db.pragma("journal_mode = WAL");

db.exec(`
  CREATE TABLE IF NOT EXISTS people (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    number INTEGER NOT NULL UNIQUE,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  )
`);

app.use(express.json({ limit: "10kb" }));
app.use(express.static(path.join(__dirname, "public")));

function getLevel(number) {
  let level = 1, start = 1;
  while (number >= start * 3) {
    start *= 3;
    level++;
  }
  return level;
}

app.get("/api/people", (req, res) => {
  const rows = db.prepare(
    "SELECT number, name, created_at FROM people ORDER BY number ASC"
  ).all();
  res.json(rows.map(p => ({ ...p, level: getLevel(p.number) })));
});

app.post("/api/register", (req, res) => {
  const name = String(req.body?.name || "").trim().replace(/\s+/g, " ");

  if (name.length < 2 || name.length > 60) {
    return res.status(400).json({ error: "الاسم خاصو يكون بين جوج و60 حرف." });
  }

  // Transaction + IMMEDIATE lock ensures two simultaneous registrations
  // cannot receive the same number.
  const register = db.transaction(() => {
    const row = db.prepare("SELECT COALESCE(MAX(number), 0) + 1 AS next FROM people").get();
    const number = row.next;
    db.prepare("INSERT INTO people (name, number) VALUES (?, ?)").run(name, number);
    return number;
  });

  try {
    const number = register();
    res.json({ ok: true, number, level: getLevel(number), name });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "وقع مشكل أثناء التسجيل." });
  }
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`Matrix site running on port ${PORT}`);
});